import streamlit as st
import pickle
import numpy as np
import pandas as pd
from database import create_table, save_transaction, get_transactions



with open("model.pkl", "rb") as file:
    model = pickle.load(file)

with open("scaler.pkl", "rb") as file:
    scaler = pickle.load(file)


create_table()
params = st.query_params


st.set_page_config(
    page_title="UPI Shield",
    layout="wide"
)

st.markdown("""
<style>


.stApp {
    background-color: #F5F7FA;
    color: #1f2937;
}


[data-testid="stSidebar"] {
    background-color: #0B1F3A;
}

[data-testid="stSidebar"] * {
    color: white !important;
}


[data-testid="stSidebar"] h1 {
    color: #F4C430 !important;
}


h1, h2, h3 {
    color: #0B1F3A !important;
}


.stApp p,
.stApp label {
    color: #1f2937;
}


.stButton > button {
    background-color: #F4C430;
    color: #0B1F3A !important;
    border: none;
    border-radius: 6px;
    font-weight: bold;
}

.stButton > button:hover {
    background-color: #DDB020;
    color: #0B1F3A !important;
}


[data-testid="stMetric"] {
    background-color: white;
    padding: 15px;
    border-radius: 10px;
    border-top: 4px solid #F4C430;
    box-shadow: 0 3px 10px rgba(0,0,0,0.08);
}

[data-testid="stMetricLabel"] {
    color: #374151 !important;
}

[data-testid="stMetricValue"] {
    color: #0B1F3A !important;
}


input {
    border-color: #D1D5DB !important;
}

</style>
""", unsafe_allow_html=True)

st.markdown("""
<style>

.main-title {
    font-size: 40px;
    font-weight: bold;
    text-align: center;
}

.subtitle {
    text-align: center;
    font-size: 18px;
    margin-bottom: 30px;
}

.result-box {
    padding: 20px;
    border-radius: 10px;
    background-color: #f5f5f5;
    margin-top: 20px;
}

</style>
""", unsafe_allow_html=True)


page = st.sidebar.radio(
    "Navigation",
    ["Home", "Dashboard", "Check Transaction", "Transaction History"]
)


if page == "Home":

    col1, col2, col3 = st.columns([1.4, 2, 0.6])

    with col2:
        st.image("upi_logo.png", width=250)

    st.markdown(
        '<div class="main-title">UPI Shield</div>',
        unsafe_allow_html=True
    )

    st.markdown(
        '<div class="subtitle">UPI Fraud Risk Detection System</div>',
        unsafe_allow_html=True
    )
    st.write(
        """
        Welcome to UPI Shield.

        This application uses a Machine Learning model to analyze
        UPI transaction details and predict whether a transaction
        has a high or low fraud risk.
        """
    )

    st.info(
        "Go to 'Check Transaction' from the sidebar to analyze a transaction."
    )


elif page == "Dashboard":

    st.title("UPI Fraud Detection Dashboard")

    transactions = get_transactions()

    if transactions:

        df = pd.DataFrame(
            transactions,
            columns=[
                "ID",
                "Hour",
                "Day",
                "Month",
                "Year",
                "Category",
                "UPI Number",
                "Age",
                "Amount",
                "State",
                "ZIP",
                "Prediction",
                "Risk",
                "Probability",
                "Created At"
            ]
        )

    

        total_transactions = len(df)

        high_risk = len(
            df[df["Prediction"] == 1]
        )

        low_risk = len(
            df[df["Prediction"] == 0]
        )

        total_amount = df["Amount"].sum()


        

        col1, col2, col3, col4 = st.columns(4)

        with col1:
            st.metric(
                "Total Transactions",
                total_transactions
            )

        with col2:
            st.metric(
                "High Risk",
                high_risk
            )

        with col3:
            st.metric(
                "Low Risk",
                low_risk
            )

        with col4:
            st.metric(
                "Total Amount",
                f"₹{total_amount:,.2f}"
            )


        st.divider()




        st.subheader("Risk Distribution")

        risk_data = pd.DataFrame({
           "Risk": ["High Risk", "Low Risk"],
           "Transactions": [high_risk, low_risk]
        })

        st.bar_chart(
           risk_data,
           x="Risk",
           y="Transactions",
           height=350
        )


        st.divider()



        st.subheader("Transaction Amount")

        amount_data = df[["ID", "Amount"]].set_index("ID")

        st.line_chart(amount_data)


        st.divider()


        

        st.subheader("Recent Transactions")

        recent = df.head(5)

        st.dataframe(
            recent[
                [
                    "UPI Number",
                    "Amount",
                    "Risk",
                    "Probability",
                    "Created At"
                ]
            ],
            use_container_width=True,
            hide_index=True
        )

    else:

        st.info(
            "No transactions available. "
            "Check a transaction first to see dashboard statistics."
        )


elif page == "Check Transaction":

    st.title("Check Transaction")

    st.subheader("Transaction Details")

    col1, col2, col3 = st.columns(3)

    with col1:
        trans_hour = st.number_input(
            "Transaction Hour",
            min_value=0,
            max_value=23,
            value=int(params.get("trans_hour", 12))
        )

    with col2:
        trans_day = st.number_input(
            "Transaction Day",
            min_value=1,
            max_value=31,
            value=int(params.get("trans_day", 1))
        )

    with col3:
        trans_month = st.number_input(
            "Transaction Month",
            min_value=1,
            max_value=12,
            value=int(params.get("trans_month", 1))
        )

    col1, col2 = st.columns(2)

    with col1:
        trans_year = st.number_input(
            "Transaction Year",
            min_value=2000,
            max_value=2100,
            value=int(params.get("trans_year", 2026))
        )

    with col2:
        category = st.number_input(
            "Category",
            min_value=0,
            value=int(params.get("category", 0))
        )


    st.subheader("Customer Details")

    col1, col2, col3 = st.columns(3)

    with col1:
        upi_number = st.number_input(
            "UPI Number",
            min_value=0,
            value=int(params.get("upi_number", 9957000001))
        )

    with col2:
        age = st.number_input(
            "Age",
            min_value=1,
            max_value=100,
            value=int(params.get("age", 25))
        )

    with col3:
        trans_amount = st.number_input(
            "Transaction Amount",
            min_value=0.0,
            value=float(params.get("trans_amount", 100.0))
        )

    col1, col2 = st.columns(2)

    with col1:
        state = st.number_input(
            "State",
            min_value=0,
            value=int(params.get("state", 0))
        )

    with col2:
        zip_code = st.number_input(
            "ZIP Code",
            min_value=0,
            value=int(params.get("zip", 211001))
        )


    st.write("")

    check_button = st.button(
        "Check Fraud Risk",
        use_container_width=True
    )




    if check_button or "trans_hour" in params:
        
        input_data = np.array([[
            trans_hour,
            trans_day,
            trans_month,
            trans_year,
            category,
            upi_number,
            age,
            trans_amount,
            state,
            zip_code
        ]])

        
        input_scaled = scaler.transform(input_data)

        
        prediction = model.predict(input_scaled)[0]

        
        probability = model.predict_proba(input_scaled)[0][1]

        
        if prediction == 1:
            risk = "High Risk"
        else:
            risk = "Low Risk"


   
        save_transaction(
            trans_hour,
            trans_day,
            trans_month,
            trans_year,
            category,
            upi_number,
            age,
            trans_amount,
            state,
            zip_code,
            int(prediction),
            risk,
            float(probability)
        )


        
        st.subheader("Prediction Result")

        if prediction == 1:

            st.error(
                f"HIGH FRAUD RISK\n\n"
                f"Fraud Probability: {probability:.2%}"
            )

        else:

            st.success(
                f"LOW FRAUD RISK\n\n"
                f"Fraud Probability: {probability:.2%}"
            )

        st.info(
            "Transaction details have been saved to the database."
        )




elif page == "Transaction History":

    st.title("Transaction History")

    transactions = get_transactions()

    if transactions:

        df_history = pd.DataFrame(
            transactions,
            columns=[
                "ID",
                "Hour",
                "Day",
                "Month",
                "Year",
                "Category",
                "UPI Number",
                "Age",
                "Amount",
                "State",
                "ZIP",
                "Prediction",
                "Risk",
                "Probability",
                "Created At"
            ]
        )

        
        df_history = df_history.drop(columns=["ID"])

        st.dataframe(
            df_history,
            column_config={
                "Amount": st.column_config.NumberColumn(
                    "Amount",
                    format="₹%.2f"
                ),
                "Probability": st.column_config.NumberColumn(
                    "Probability",
                    format="%.2f"
                )
            },
            use_container_width=True,
            hide_index=True
        )

    else:

        st.info("No transactions found yet.")