import sqlite3


DATABASE = "transactions.db"


def create_table():
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trans_hour INTEGER,
            trans_day INTEGER,
            trans_month INTEGER,
            trans_year INTEGER,
            category INTEGER,
            upi_number INTEGER,
            age INTEGER,
            trans_amount REAL,
            state INTEGER,
            zip_code INTEGER,
            prediction INTEGER,
            risk TEXT,
            probability REAL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()


def save_transaction(
    trans_hour,
    trans_day,
    trans_month,
    trans_year,
    category,
    upi_number,
    age,
    trans_amount,
    state,
    zip_code,
    prediction,
    risk,
    probability
):

    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()

    cursor.execute("""
        INSERT INTO transactions (
            trans_hour,
            trans_day,
            trans_month,
            trans_year,
            category,
            upi_number,
            age,
            trans_amount,
            state,
            zip_code,
            prediction,
            risk,
            probability
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        trans_hour,
        trans_day,
        trans_month,
        trans_year,
        category,
        upi_number,
        age,
        trans_amount,
        state,
        zip_code,
        prediction,
        risk,
        probability
    ))

    conn.commit()
    conn.close()


def get_transactions():

    conn = sqlite3.connect(DATABASE)

    data = conn.execute("""
        SELECT *
        FROM transactions
        ORDER BY id DESC
    """).fetchall()

    conn.close()

    return data