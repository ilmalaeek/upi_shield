const checkButton = document.getElementById("checkButton");
const result = document.getElementById("result");

checkButton.addEventListener("click", function () {

    const trans_hour = document.getElementById("trans_hour").value;
    const trans_day = document.getElementById("trans_day").value;
    const trans_month = document.getElementById("trans_month").value;
    const trans_year = document.getElementById("trans_year").value;
    const category = document.getElementById("category").value;

    const upi_number = document.getElementById("upi_number").value;
    const age = document.getElementById("age").value;
    const trans_amount = document.getElementById("trans_amount").value;
    const state = document.getElementById("state").value;
    const zip = document.getElementById("zip").value;


    
    if (
        trans_hour === "" ||
        trans_day === "" ||
        trans_month === "" ||
        trans_year === "" ||
        category === "" ||
        upi_number === "" ||
        age === "" ||
        trans_amount === "" ||
        state === "" ||
        zip === ""
    ) {
        result.innerHTML = "<p>Please fill all fields.</p>";
        return;
    }


    
    if (trans_hour < 0 || trans_hour > 23) {
        result.innerHTML = "<p>Hour must be between 0 and 23.</p>";
        return;
    }

    if (trans_day < 1 || trans_day > 31) {
        result.innerHTML = "<p>Day must be between 1 and 31.</p>";
        return;
    }

    if (trans_month < 1 || trans_month > 12) {
        result.innerHTML = "<p>Month must be between 1 and 12.</p>";
        return;
    }

    if (age < 1 || age > 100) {
        result.innerHTML = "<p>Please enter a valid age.</p>";
        return;
    }

    if (trans_amount < 0) {
        result.innerHTML = "<p>Transaction amount cannot be negative.</p>";
        return;
    }


    
    const streamlitURL =
        "http://localhost:8501" +
        "?trans_hour=" + encodeURIComponent(trans_hour) +
        "&trans_day=" + encodeURIComponent(trans_day) +
        "&trans_month=" + encodeURIComponent(trans_month) +
        "&trans_year=" + encodeURIComponent(trans_year) +
        "&category=" + encodeURIComponent(category) +
        "&upi_number=" + encodeURIComponent(upi_number) +
        "&age=" + encodeURIComponent(age) +
        "&trans_amount=" + encodeURIComponent(trans_amount) +
        "&state=" + encodeURIComponent(state) +
        "&zip=" + encodeURIComponent(zip);


    
    window.location.href = streamlitURL;

});